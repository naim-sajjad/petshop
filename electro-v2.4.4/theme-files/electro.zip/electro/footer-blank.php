<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package electro
 */
?>

		</div><!-- .col-full -->
	</div><!-- #content -->

</div><!-- #page -->
</div>

<?php do_action( 'electro_after_page' ); ?>

<?php wp_footer(); ?>

</body>
</html>
